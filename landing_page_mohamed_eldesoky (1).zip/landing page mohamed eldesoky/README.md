
* landing page Architecture
-index.HTML
-app.js
-style.CSS
the project is about creating dynamic navigation bar 

1- create fargment for best performance 
2-create variable sectionList contain all sections
3 create nav bar variable (ul);
4- create loop forEach to create li and link nav bar with its section 
5- add event listener to nave bar "click" to link between nav bar and section 
6- put li in fragment
7- put fragment in ul 
8- use getBoundingclintRect to  section is being viewed while scrolling through the page.

all codes I've  used throgh this project :
* Document.querySelectorAll();

 * Document.getElementById();

 * forEach();

 * Document.createDocumentFragment();

 * Document.createElement();

 * Document.createTextNode();

 * appendChild();

 * getAttribute();

 * scrollIntoView({'behavior':'smooth'});



 Active Section Methods:
 * Document.querySelectorAll();

 * forEach();

 * getBoundingClientRect();

 * classList.remove();

 * classList.add();

 * getAttribute();

