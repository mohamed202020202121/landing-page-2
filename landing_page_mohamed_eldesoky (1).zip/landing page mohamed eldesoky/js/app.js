//create fragment for better prefomance



const fragment = document.createDocumentFragment();
// create global Variables
//call all section by querySelectorAll
const sectionList = document.querySelectorAll('section');
//create ul
const navbar = document.getElementById("navbar__list");




sectionList.forEach((section)=>{
  //bring name of li by 'data-nav'
    const newData = section.getAttribute('data-nav');
// create li
    const newli = document.createElement('li');
    // change markup by js
    newli.setAttribute('style','color:black ; font : bold 20px Gorigia , seif ;padding: 3px;')
    //newli.getAttribute(".active-nav")
    //put name of li (section)
    newli.innerHTML = newData;
    // create event listener to like between ul and sections by click
    newli.addEventListener('click', ()=>{
        section.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"})
    });
    //put li in fragment
    fragment.appendChild(newli)
});
//put fragment in ul
navbar.appendChild(fragment);

// create active section by array
function active(section){
  //use forEach method on sectionList
  sectionList.forEach((section)=>{
    


    //use get getBoundingClientRect
    const rect =section.getBoundingClientRect();
    //use the return porperties relate to view port and section
    //use if statement to get active like

    if (rect.top>0 && rect.top <= 300){
      // use classList.add method to add active section 
     
      section.classList.add("your-active-class")
      
    } else {
     
      section.classList.remove("your-active-class")
     
      }
    
  });
}

window.addEventListener('scroll',active)

